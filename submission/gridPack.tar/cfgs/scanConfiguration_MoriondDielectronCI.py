
leptons = "elel"
systematics = ["sigEff","bkgUncert","massScale"]
#systematics = ["bkgUncert","massScale"]
correlate = False
#systematics = ["massScale","sigEff"]
lambdas = [[1000,1000,10001]]
#massesExp = [[250,2750,2800,100,10,500000]]
#massesExp = [[250,2000,4600,500,2,1000000]]

binning = [400,500,700,1100,1900,3500]

libraries = ["ZPrimeBkgPdf_cxx.so","PowFunc_cxx.so","RooCruijff_cxx.so"]

#channels = ["dimuon_BB","dimuon_BEpos","dimuon_BEneg"]
channels = ["dielectron_Moriond2017CI_EBEB_CSPos","dielectron_Moriond2017CI_EBEB_CSNeg","dielectron_Moriond2017CI_EBEE_CSPos","dielectron_Moriond2017CI_EBEE_CSNeg"]
numInt = 500000
numToys = 10
exptToys = 500
width = 0.006
submitTo = "Purdue"

binWidth = 10
CB = True
signalInjection = {"mass":750,"width":0.1000,"nEvents":100,"CB":True}
		
