leptons = "mumu"
systematics = ["bkgUncert",'res','massScale']
correlate = False

lambdas = [[1000,1000,10001]]

binning = [400,500,700,1100,1900,3500]

libraries = ["ZPrimeMuonBkgPdf2_cxx.so","PowFunc_cxx.so"]

channels = ["dimuon_Moriond2017CI_BB_CSPos","dimuon_Moriond2017CI_BE_CSPos","dimuon_Moriond2017CI_BB_CSNeg","dimuon_Moriond2017CI_BE_CSNeg"]
numInt = 500000
numToys = 6
exptToys = 500
submitTo = "Purdue"

		
